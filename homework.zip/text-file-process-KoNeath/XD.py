import os



if __name__ == '__main__':
    iid=input()
    a=0
    for root, dirs, files in os.walk(r'C:\Users\Ko_Ne\Desktop\text-file-process-KoNeath'):
        if os.path.splitext(files)[0]==iid:
            f=open('files','r')
            for lines in f:
                part=lines.split(':',-1)[2]
                number=part.split(',',-1)[0]
                if iid==number:
                    a=a+1
            f.close()

    print(a)